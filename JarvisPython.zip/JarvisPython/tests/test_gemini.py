import json
import os
import tempfile
import unittest

import requests

from jarvis.config import Settings
from jarvis.gemini_service import AIStatus, GeminiError, GeminiService


class FakeResp:
    def __init__(self, status, body):
        self.status_code = status
        self._body = body
        self.text = json.dumps(body)

    def json(self):
        return self._body


class FakeSession:
    def __init__(self, resp=None, exc=None):
        self.resp = resp
        self.exc = exc

    def post(self, url, **kwargs):
        if self.exc:
            raise self.exc
        return self.resp


def make_settings():
    os.environ.pop("GEMINI_API_KEY", None)
    s = Settings(home=tempfile.mkdtemp())
    s.set_api_key("test-key-123456")
    return s


class GeminiTests(unittest.TestCase):
    def test_success_returns_text(self):
        body = {"candidates": [{"content": {"parts": [{"text": "Haan, main yahin hoon."}]}}]}
        g = GeminiService(make_settings(), FakeSession(FakeResp(200, body)))
        self.assertEqual(g.ask("hello"), "Haan, main yahin hoon.")
        self.assertEqual(g.status, AIStatus.CONNECTED)

    def test_invalid_key_is_error(self):
        body = {"error": {"message": "API key not valid. Please pass a valid API key."}}
        g = GeminiService(make_settings(), FakeSession(FakeResp(400, body)))
        with self.assertRaises(GeminiError) as ctx:
            g.ask("hi")
        self.assertIn("API key", str(ctx.exception))
        self.assertEqual(g.status, AIStatus.ERROR)

    def test_rate_limit_message(self):
        g = GeminiService(make_settings(), FakeSession(FakeResp(429, {"error": {"message": "quota"}})))
        with self.assertRaises(GeminiError) as ctx:
            g.ask("hi")
        self.assertIn("Rate limit", str(ctx.exception))

    def test_network_failure_is_disconnected(self):
        g = GeminiService(make_settings(), FakeSession(exc=requests.ConnectionError()))
        with self.assertRaises(GeminiError):
            g.ask("hi")
        self.assertEqual(g.status, AIStatus.DISCONNECTED)

    def test_missing_key(self):
        s = Settings(home=tempfile.mkdtemp())
        os.environ.pop("GEMINI_API_KEY", None)
        g = GeminiService(s, FakeSession(FakeResp(200, {})))
        with self.assertRaises(GeminiError):
            g.ask("hi")


if __name__ == "__main__":
    unittest.main()
