import unittest

from jarvis.music import is_music_command, parse_music_query, youtube_search_url


class MusicTests(unittest.TestCase):
    def test_artist_and_mood(self):
        self.assertEqual(
            parse_music_query("Jarvis, Arijit Singh ka romantic song chalao."),
            "arijit singh romantic",
        )

    def test_favourite_search(self):
        self.assertEqual(parse_music_query("Mera favourite song search karo"), "favourite")

    def test_detects_music_command(self):
        self.assertTrue(is_music_command("gaana chala do"))

    def test_display_settings_is_not_music(self):
        self.assertFalse(is_music_command("display settings kholo"))

    def test_search_url_encodes_query(self):
        self.assertIn("search_query=arijit+singh", youtube_search_url("arijit singh"))


if __name__ == "__main__":
    unittest.main()
