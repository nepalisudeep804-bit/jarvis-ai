import os
import tempfile
import unittest
from unittest import mock

from jarvis.assistant import Assistant
from jarvis.config import Settings
from jarvis.memory import Memory


class FakeGemini:
    def ask(self, text, history):
        return "AI jawab"


class FakeLive:
    pass


def make_assistant():
    os.environ.pop("GEMINI_API_KEY", None)
    home = tempfile.mkdtemp()
    s = Settings(home=home)
    m = Memory(os.path.join(home, "memory.json"))
    return Assistant(s, m, FakeGemini(), FakeLive()), m


class AssistantTests(unittest.TestCase):
    def test_empty_input(self):
        a, _ = make_assistant()
        self.assertIn("sun rahi", a.handle("   "))

    def test_unknown_goes_to_ai(self):
        a, _ = make_assistant()
        self.assertEqual(a.handle("Tum kya kar rahi ho?"), "AI jawab")

    def test_tasks_flow(self):
        a, m = make_assistant()
        a.handle("task add doodh lena")
        self.assertIn("doodh lena", a.handle("tasks dikhao"))
        self.assertEqual(len(m.tasks()), 1)

    def test_preference_saved(self):
        a, m = make_assistant()
        a.handle("yaad rakho mujhe chai pasand hai")
        self.assertEqual(m.preferences(), ["mujhe chai pasand hai"])

    def test_dial_needs_confirmation(self):
        a, _ = make_assistant()
        with mock.patch("jarvis.android_actions.dial") as dial:
            question = a.handle("call 98765 43210 karo")
            self.assertIn("dialer", question)
            dial.assert_not_called()
            a.handle("haan")
            dial.assert_called_once_with("9876543210")

    def test_dial_cancelled(self):
        a, _ = make_assistant()
        with mock.patch("jarvis.android_actions.dial") as dial:
            a.handle("call 98765 43210 karo")
            self.assertIn("cancel", a.handle("nahi"))
            dial.assert_not_called()


if __name__ == "__main__":
    unittest.main()
