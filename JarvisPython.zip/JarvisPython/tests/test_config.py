import os
import stat
import tempfile
import unittest

from jarvis.config import Settings


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.environ.pop("GEMINI_API_KEY", None)

    def test_bool_and_int_parsing(self):
        s = Settings(home=self.tmp)
        self.assertFalse(s.set("memory_enabled", "off"))
        self.assertEqual(s.set("affection_level", "3"), 3)

    def test_invalid_values_rejected(self):
        s = Settings(home=self.tmp)
        with self.assertRaises(ValueError):
            s.set("affection_level", "9")
        with self.assertRaises(KeyError):
            s.set("no_such_key", "x")

    def test_settings_persist_across_instances(self):
        Settings(home=self.tmp).set("nickname", "Priya")
        self.assertEqual(Settings(home=self.tmp).get("nickname"), "Priya")

    def test_api_key_file_is_private(self):
        s = Settings(home=self.tmp)
        s.set_api_key("abcd1234efgh5678")
        mode = stat.S_IMODE(os.stat(s._secret_path).st_mode)
        self.assertEqual(mode, 0o600)
        self.assertEqual(s.masked_key(), "abcd...5678")


if __name__ == "__main__":
    unittest.main()
