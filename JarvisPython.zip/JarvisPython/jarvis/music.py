"""Music command detect karna aur gaane ka naam nikaalna."""
from urllib.parse import quote_plus

from .text_utils import has_word, normalize

MUSIC_WORDS = ("gaana", "gana", "gaane", "song", "songs", "music",
               "chalao", "chalaao", "chala do", "bajao", "play", "गाना", "गाने")

NOISE = {
    "jarvis", "youtube", "par", "pe", "chalao", "chalaao", "chala", "do", "bajao",
    "play", "karo", "kholo", "khol", "mera", "meri", "mere", "mujhe", "wala", "wali",
    "wale", "gaana", "gana", "gaane", "song", "songs", "music", "ka", "ki", "ke",
    "search", "liye",
}


def is_music_command(text):
    return has_word(text, *MUSIC_WORDS)


def parse_music_query(text):
    kept = [w for w in normalize(text).split() if w not in NOISE]
    return " ".join(kept).strip()


def youtube_search_url(query):
    return "https://www.youtube.com/results?search_query=" + quote_plus(query)
