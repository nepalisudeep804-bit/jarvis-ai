"""Chat history, preferences aur tasks ka local storage. Sirf local file me."""
import json
import os
from pathlib import Path

EMPTY = {"history": [], "preferences": [], "tasks": []}


class Memory:
    def __init__(self, path, enabled=True, max_messages=30):
        self.path = Path(path)
        self.enabled = enabled
        self.max_messages = max_messages
        self.data = {k: [] for k in EMPTY}
        if self.path.exists():
            try:
                saved = json.loads(self.path.read_text(encoding="utf-8"))
                for k in EMPTY:
                    if isinstance(saved.get(k), list):
                        self.data[k] = saved[k]
            except (ValueError, OSError):
                pass  # corrupt file ho to khali se shuru

    def add_message(self, role, text):
        if not self.enabled:
            return
        self.data["history"].append({"role": role, "text": text})
        self.data["history"] = self.data["history"][-self.max_messages:]
        self._save()

    def recent(self, n=8):
        if not self.enabled:
            return []
        return [dict(m) for m in self.data["history"][-n:]]

    def add_preference(self, text):
        self.data["preferences"].append(text)
        self._save()

    def preferences(self):
        return list(self.data["preferences"])

    def add_task(self, text):
        self.data["tasks"].append({"text": text, "done": False})
        self._save()

    def tasks(self):
        return [dict(t) for t in self.data["tasks"]]

    def complete_task(self, number):
        idx = number - 1
        if 0 <= idx < len(self.data["tasks"]):
            self.data["tasks"][idx]["done"] = True
            self._save()
            return True
        return False

    def clear_history(self):
        self.data["history"] = []
        self._save()

    def clear_all(self):
        self.data = {k: [] for k in EMPTY}
        self._save()

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)
