"""Termux:API se bolna (TTS) aur sunna (speech-to-text)."""
import shutil
import subprocess


class VoiceUnavailable(Exception):
    pass


class Voice:
    def __init__(self, language="hi-IN", rate=1.0):
        self.language = language
        self.rate = rate
        self._proc = None

    @property
    def can_listen(self):
        return shutil.which("termux-speech-to-text") is not None

    @property
    def can_speak(self):
        return shutil.which("termux-tts-speak") is not None

    def listen(self, timeout=25):
        """Ek baar sunta hai. Bolne ke dauraan koi speaking nahi chalti (self-listening se bachav)."""
        if not self.can_listen:
            raise VoiceUnavailable(
                "termux-speech-to-text nahi mila. Termux:API app install karein aur "
                "'pkg install termux-api' chalayein."
            )
        try:
            out = subprocess.run(["termux-speech-to-text"], capture_output=True,
                                 text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return None
        return out.stdout.strip() or None

    def speak(self, text):
        """Text bolta hai aur khatam hone tak wait karta hai."""
        self.stop()
        if not self.can_speak:
            return False
        self._proc = subprocess.Popen(
            ["termux-tts-speak", "-l", self.language, "-r", str(self.rate), text]
        )
        try:
            self._proc.wait()
        finally:
            self._proc = None
        return True

    def stop(self):
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
        self._proc = None
