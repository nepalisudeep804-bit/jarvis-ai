"""JARVIS AI - Termux ke liye Python voice/text assistant."""
