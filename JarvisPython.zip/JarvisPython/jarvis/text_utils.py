"""Text matching helpers. ASCII shabd poore word ke roop me match hote hain."""
import re

_NON_WORD = re.compile(r"[^\w\s]")


def normalize(text):
    return " " + _NON_WORD.sub(" ", text.lower()) + " "


def has_word(text, *words):
    norm = normalize(text)
    low = text.lower()
    for w in words:
        if w.isascii():
            if f" {w} " in norm:
                return True
        elif w in low:
            return True
    return False


def has_any(text, *phrases):
    low = text.lower()
    return any(p in low for p in phrases)
