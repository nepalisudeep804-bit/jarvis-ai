"""Google Gemini se baat karne ki service layer (REST API, requests se)."""
from enum import Enum

import requests

API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
TIMEOUT = 30

LENGTH_HINT = {
    "short": "Jawab 2-3 chhote vakyon mein do.",
    "medium": "Jawab 4-6 vakyon mein do.",
    "long": "Jawab detail se do, lekin saaf rakho.",
}
AFFECTION_HINT = {
    0: "Bahut neutral aur professional raho.",
    1: "Friendly aur respectful raho.",
    2: "Warm aur caring raho, kabhi-kabhi pyaar bhari baat bhi.",
    3: "Affectionate aur playful raho, par har jawab romantic mat banao.",
}


class AIStatus(str, Enum):
    CONNECTED = "Connected"
    DISCONNECTED = "Disconnected"
    ERROR = "Error"


class GeminiError(Exception):
    pass


class GeminiService:
    def __init__(self, settings, session=None):
        self.settings = settings
        self.session = session or requests.Session()
        self.status = AIStatus.DISCONNECTED
        self.last_error = ""

    def system_prompt(self):
        s = self.settings
        return (
            f"Tum {s.get('nickname')} ho, ek smart, warm aur caring female AI assistant. "
            "User jis bhasha me bole (Hindi, Hinglish ya English) usi me jawab do. "
            f"{LENGTH_HINT[s.get('response_length')]} "
            f"{AFFECTION_HINT[int(s.get('affection_level'))]} "
            "Tum insaan nahi ho; apne liye physical presence ya asli feelings ka dava mat karo. "
            "Live data (mausam, news, price, time) ke baare me apni purani knowledge ko sach mat maano; "
            "agar live data nahi diya gaya, to saaf kaho ki tum abhi check nahi kar sakti."
        )

    def ask(self, text, history=None):
        key = self.settings.get_api_key()
        if not key:
            raise self._fail("API key set nahi hai. /setkey se key dalein.", AIStatus.DISCONNECTED)

        contents = []
        for m in history or []:
            role = "user" if m.get("role") == "user" else "model"
            contents.append({"role": role, "parts": [{"text": m.get("text", "")}]})
        contents.append({"role": "user", "parts": [{"text": text}]})

        payload = {
            "systemInstruction": {"parts": [{"text": self.system_prompt()}]},
            "contents": contents,
            "generationConfig": {
                "temperature": float(self.settings.get("temperature")),
                "maxOutputTokens": int(self.settings.get("max_output_tokens")),
            },
        }
        url = API_URL.format(model=self.settings.get("gemini_model"))
        headers = {"x-goog-api-key": key, "Content-Type": "application/json"}

        try:
            resp = self.session.post(url, headers=headers, json=payload, timeout=TIMEOUT)
        except requests.Timeout:
            raise self._fail("Network timeout ho gaya.", AIStatus.DISCONNECTED)
        except requests.RequestException:
            raise self._fail("Internet connection nahi mil raha.", AIStatus.DISCONNECTED)

        if resp.status_code != 200:
            detail = self._error_detail(resp)
            code = resp.status_code
            if code in (401, 403) or (code == 400 and "api key" in detail.lower()):
                msg = "API key galat ya band hai."
            elif code == 429:
                msg = "Rate limit ya quota khatam ho gaya. Thodi der baad try karein."
            elif code >= 500:
                msg = "Gemini server par problem hai. Baad me try karein."
            else:
                msg = f"Request fail hui (HTTP {code}): {detail}"
            raise self._fail(msg)

        try:
            data = resp.json()
        except ValueError:
            raise self._fail("Gemini ka response samajh nahi aaya.")

        candidates = data.get("candidates") or []
        if not candidates:
            reason = (data.get("promptFeedback") or {}).get("blockReason", "unknown")
            raise self._fail(f"Gemini ne jawab nahi diya (reason: {reason}).")

        parts = (candidates[0].get("content") or {}).get("parts") or []
        answer = "".join(p.get("text", "") for p in parts).strip()
        if not answer:
            raise self._fail("Gemini ka response khali aaya.")

        self.status = AIStatus.CONNECTED
        self.last_error = ""
        return answer

    def test_connection(self):
        try:
            answer = self.ask("Ek shabd me jawab do: connected?", history=[])
            return True, f"Connected. Jawab: {answer[:80]}"
        except GeminiError as e:
            return False, str(e)

    def _fail(self, msg, status=AIStatus.ERROR):
        self.status = status
        self.last_error = msg
        return GeminiError(msg)

    @staticmethod
    def _error_detail(resp):
        try:
            return resp.json()["error"]["message"]
        except (ValueError, KeyError, TypeError):
            return (resp.text or "")[:200]
