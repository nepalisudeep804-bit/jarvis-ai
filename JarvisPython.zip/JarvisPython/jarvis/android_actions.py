"""Android par asli actions: Termux:API commands aur 'am start' intents.

Note: 'am' aur 'monkey' kuch Android versions par restricted ho sakte hain.
Har function fail hone par ActionError deta hai, aur success ka claim sirf tab karta hai
jab command ka exit code 0 ho.
"""
import json
import shutil
import subprocess
from urllib.parse import quote_plus


class ActionError(Exception):
    pass


APP_PACKAGES = {
    "youtube": "com.google.android.youtube",
    "whatsapp": "com.whatsapp",
    "chrome": "com.android.chrome",
    "maps": "com.google.android.apps.maps",
    "gmail": "com.google.android.gm",
    "spotify": "com.spotify.music",
    "instagram": "com.instagram.android",
}

SETTINGS_ACTIONS = {
    "wifi": "android.settings.WIFI_SETTINGS",
    "bluetooth": "android.settings.BLUETOOTH_SETTINGS",
    "display": "android.settings.DISPLAY_SETTINGS",
    "sound": "android.settings.SOUND_SETTINGS",
}

SETTINGS_KEYWORDS = {
    "wifi": ("wifi", "wi fi"),
    "bluetooth": ("bluetooth",),
    "display": ("display", "screen"),
    "sound": ("sound", "awaaz"),
}


def _run(args, timeout=15):
    if shutil.which(args[0]) is None:
        raise ActionError(f"'{args[0]}' command nahi mila. Termux:API install karein.")
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise ActionError(f"'{args[0]}' ne time par jawab nahi diya.")


def _am_start(*args):
    res = _run(["am", "start", *args])
    combined = (res.stdout or "") + (res.stderr or "")
    if res.returncode != 0 or "Error" in combined:
        raise ActionError("Android ne ye intent launch nahi kiya.")
    return "khol diya gaya."


def open_url(url):
    res = _run(["termux-open-url", url])
    if res.returncode != 0:
        raise ActionError("URL nahi khul paya.")


def open_youtube(query=None):
    if query:
        open_url("https://www.youtube.com/results?search_query=" + quote_plus(query))
        return f"YouTube par '{query}' ka search khol diya. Jo video chahiye wo select karein."
    open_url("https://www.youtube.com")
    return "YouTube khol diya."


def open_app(name):
    pkg = APP_PACKAGES.get(name)
    if not pkg:
        raise ActionError(f"'{name}' ka package mapping me nahi hai.")
    res = _run(["monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"])
    if res.returncode != 0:
        raise ActionError(f"{name} nahi khul paya.")
    return f"{name} khol diya."


def torch(turn_on):
    res = _run(["termux-torch", "on" if turn_on else "off"])
    if res.returncode != 0:
        raise ActionError("Torch control nahi ho paya (device me flash nahi ho sakta).")
    return "Torch on kar di." if turn_on else "Torch band kar di."


def change_volume(up, step=1):
    res = _run(["termux-volume"])
    try:
        streams = json.loads(res.stdout)
    except ValueError:
        raise ActionError("Volume ki jaankari nahi mil payi.")
    music = next((s for s in streams if s.get("stream") == "music"), None)
    if not music:
        raise ActionError("Music volume stream nahi mila.")
    current, maximum = int(music["volume"]), int(music["max_volume"])
    new = max(0, min(maximum, current + (step if up else -step)))
    res = _run(["termux-volume", "music", str(new)])
    if res.returncode != 0:
        raise ActionError("Volume set nahi ho paya.")
    return f"Volume {'badha' if up else 'kam'} diya: {new}/{maximum}."


def battery():
    res = _run(["termux-battery-status"])
    try:
        info = json.loads(res.stdout)
    except ValueError:
        raise ActionError("Battery ki jaankari nahi mil payi.")
    return f"Battery {info.get('percentage')}% hai, status: {info.get('status', 'unknown')}."


def open_settings(name):
    action = SETTINGS_ACTIONS.get(name)
    if not action:
        raise ActionError("Ye settings screen supported nahi hai.")
    return f"{name} settings {_am_start('-a', action)}"


def open_camera():
    return "Camera " + _am_start("-a", "android.media.action.STILL_IMAGE_CAMERA")


def dial(number):
    """Sirf dialer kholta hai, call nahi lagata. Call user khud dabayega."""
    return _am_start("-a", "android.intent.action.DIAL", "-d", f"tel:{number}")


def draft_sms(number, body):
    """Messages app me draft kholta hai, bheji nahi jaati."""
    return _am_start("-a", "android.intent.action.SENDTO", "-d", f"smsto:{number}",
                     "--es", "sms_body", body)


def directions(destination):
    open_url("https://www.google.com/maps/dir/?api=1&destination=" + quote_plus(destination))
    return f"'{destination}' ka rasta Maps me khol diya."


def set_alarm(hour, minute, label):
    """Clock app me alarm pre-fill karta hai. User ko save karna hota hai."""
    _am_start(
        "-a", "android.intent.action.SET_ALARM",
        "--ei", "android.intent.extra.alarm_hour", str(hour),
        "--ei", "android.intent.extra.alarm_minutes", str(minute),
        "--es", "android.intent.extra.alarm_message", label,
        "--ez", "android.intent.extra.alarm_skip_ui", "false",
    )
    return f"Clock app me {hour:02d}:{minute:02d} ka alarm bhar diya hai. Save karke confirm karein."


def set_timer(seconds, label):
    _am_start(
        "-a", "android.intent.action.SET_TIMER",
        "--ei", "android.intent.extra.alarm_length", str(seconds),
        "--ez", "android.intent.extra.alarm_skip_ui", "false",
        "--es", "android.intent.extra.alarm_message", label,
    )
    return f"Timer ({seconds} second) Clock app me set karne ke liye khol diya hai."
