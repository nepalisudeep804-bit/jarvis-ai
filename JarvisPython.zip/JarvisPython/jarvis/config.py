"""Settings aur API key ka storage (Termux home ke ~/.jarvis folder me)."""
import json
import os
from pathlib import Path

HOME_DIR = Path(os.environ.get("JARVIS_HOME", Path.home() / ".jarvis"))

DEFAULTS = {
    "gemini_model": "gemini-2.5-flash",
    "temperature": 0.7,
    "max_output_tokens": 512,
    "response_length": "short",   # short | medium | long
    "affection_level": 2,         # 0 (neutral) se 3 (zyada affectionate)
    "nickname": "Jarvis",
    "tts_language": "hi-IN",      # Termux TTS ki language (hi-IN, en-US ...)
    "speech_rate": 1.0,
    "memory_enabled": True,
    "default_city": "Delhi",
    "news_language": "hi",
    "news_region": "IN",
}

VALID_LENGTHS = ("short", "medium", "long")


class Settings:
    def __init__(self, home=None):
        self.home = Path(home) if home else HOME_DIR
        self.home.mkdir(parents=True, exist_ok=True)
        self._config_path = self.home / "config.json"
        self._secret_path = self.home / "secrets.json"
        self.data = dict(DEFAULTS)
        if self._config_path.exists():
            saved = json.loads(self._config_path.read_text(encoding="utf-8"))
            for key, value in saved.items():
                if key in DEFAULTS:
                    self.data[key] = value

    def get(self, key):
        return self.data[key]

    def set(self, key, raw_value):
        if key not in DEFAULTS:
            raise KeyError(f"'{key}' ek valid setting nahi hai")
        default = DEFAULTS[key]
        if isinstance(default, bool):
            value = str(raw_value).lower() in ("1", "true", "yes", "on", "haan")
        elif isinstance(default, int):
            value = int(raw_value)
        elif isinstance(default, float):
            value = float(raw_value)
        else:
            value = str(raw_value).strip()
        if key == "affection_level" and not 0 <= value <= 3:
            raise ValueError("affection_level 0 se 3 ke beech hona chahiye")
        if key == "response_length" and value not in VALID_LENGTHS:
            raise ValueError("response_length: short, medium ya long hona chahiye")
        if key == "speech_rate" and not 0.1 <= value <= 3.0:
            raise ValueError("speech_rate 0.1 se 3.0 ke beech hona chahiye")
        self.data[key] = value
        self._write()
        return value

    def reset(self):
        self.data = dict(DEFAULTS)
        self._write()

    def _write(self):
        tmp = self._config_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self._config_path)

    # ---- API key ----
    def get_api_key(self):
        env_key = os.environ.get("GEMINI_API_KEY")
        if env_key:
            return env_key.strip()
        if self._secret_path.exists():
            data = json.loads(self._secret_path.read_text(encoding="utf-8"))
            return data.get("gemini_api_key")
        return None

    def set_api_key(self, key):
        key = (key or "").strip()
        if not key:
            raise ValueError("API key khali nahi ho sakti")
        self._secret_path.write_text(json.dumps({"gemini_api_key": key}), encoding="utf-8")
        os.chmod(self._secret_path, 0o600)  # sirf is app user ko padhne do

    def clear_api_key(self):
        if self._secret_path.exists():
            self._secret_path.unlink()

    def masked_key(self):
        key = self.get_api_key()
        if not key:
            return "(set nahi hai)"
        return key[:4] + "..." + key[-4:] if len(key) > 8 else "****"
