"""Live information: mausam (Open-Meteo), news (Google News RSS), currency (Frankfurter).
Ye sab bina API key ke chalte hain."""
import xml.etree.ElementTree as ET

import requests

TIMEOUT = 10
GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
NEWS_URL = "https://news.google.com/rss/search"
FX_URL = "https://api.frankfurter.app/latest"

WEATHER_CODES = {
    0: "saaf aasman", 1: "thoda saaf", 2: "aadhe baadal", 3: "baadal chhaaye hue",
    45: "kohra", 48: "kohra", 51: "halki boondabandi", 53: "boondabandi",
    55: "tez boondabandi", 61: "halki baarish", 63: "baarish", 65: "tez baarish",
    80: "baarish ki bauchhar", 81: "baarish ki bauchhar", 82: "tez baarish ki bauchhar",
    95: "garaj ke saath baarish",
}


class LiveInfoError(Exception):
    pass


class LiveInfo:
    def __init__(self, session=None):
        self.session = session or requests.Session()

    def _get(self, url, params=None):
        try:
            resp = self.session.get(url, params=params, timeout=TIMEOUT)
            resp.raise_for_status()
            return resp
        except requests.RequestException as e:
            raise LiveInfoError(f"Live data abhi nahi mil paya ({e.__class__.__name__}).")

    def _get_json(self, url, params=None):
        try:
            return self._get(url, params).json()
        except ValueError:
            raise LiveInfoError("Data service ka response samajh nahi aaya.")

    def weather(self, city):
        geo = self._get_json(GEOCODE_URL, {"name": city, "count": 1, "language": "en"})
        results = geo.get("results") or []
        if not results:
            raise LiveInfoError(f"'{city}' ka location nahi mila.")
        place = results[0]
        fc = self._get_json(FORECAST_URL, {
            "latitude": place["latitude"],
            "longitude": place["longitude"],
            "current": "temperature_2m,weather_code",
            "daily": "precipitation_probability_max",
            "timezone": "auto",
            "forecast_days": 1,
        })
        cur = fc.get("current") or {}
        desc = WEATHER_CODES.get(cur.get("weather_code"), "mausam")
        text = f"{place.get('name', city)} mein abhi {cur.get('temperature_2m')}°C, {desc}."
        rain = (fc.get("daily") or {}).get("precipitation_probability_max") or []
        if rain and rain[0] is not None:
            text += f" Aaj baarish ki sambhavna lagbhag {rain[0]}% hai."
        return text

    def news(self, topic="", lang="hi", region="IN", limit=3):
        query = topic.strip() or ("top news India" if region == "IN" else "top news")
        resp = self._get(NEWS_URL, {"q": query, "hl": lang, "gl": region, "ceid": f"{region}:{lang}"})
        try:
            root = ET.fromstring(resp.content)
        except ET.ParseError:
            raise LiveInfoError("News feed samajh nahi aaya.")
        titles = [i.findtext("title", default="").strip()
                  for i in root.findall("./channel/item")[:limit]]
        titles = [t for t in titles if t]
        if not titles:
            raise LiveInfoError("Abhi koi news nahi mili.")
        return "Taaza headlines:\n" + "\n".join(f"{n}. {t}" for n, t in enumerate(titles, 1))

    def convert(self, amount, src, dst):
        src, dst = src.upper(), dst.upper()
        data = self._get_json(FX_URL, {"amount": amount, "from": src, "to": dst})
        rates = data.get("rates") or {}
        if dst not in rates:
            raise LiveInfoError("Currency code galat lag raha hai.")
        return f"{amount:g} {src} ≈ {rates[dst]} {dst} (rate date: {data.get('date')})"
