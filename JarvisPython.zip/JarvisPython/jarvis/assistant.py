"""Brain: user ki baat samajhkar sahi action chalata hai, warna Gemini se jawab leta hai."""
import re
from datetime import datetime

from . import android_actions as act
from .android_actions import ActionError, APP_PACKAGES, SETTINGS_KEYWORDS
from .gemini_service import GeminiError
from .live_info import LiveInfoError
from .music import is_music_command, parse_music_query
from .text_utils import has_any, has_word, normalize

NUMBER_RE = re.compile(r"\+?\d[\d\s-]{6,}\d")
CURRENCY_RE = re.compile(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]{3})\s+(?:to|se|into|in|mein)\s+([a-zA-Z]{3})\b",
                         re.IGNORECASE)
YES_WORDS = ("haan", "ha", "yes", "kar", "karo", "ok", "confirm", "theek")
NO_WORDS = ("nahi", "no", "cancel", "rehne")
TIME_UNITS = {"second": 1, "sec": 1, "minute": 60, "min": 60,
              "ghante": 3600, "ghanta": 3600, "hour": 3600}
MAPS_STOP = {
    "jarvis", "rasta", "route", "direction", "directions", "dikhao", "batao", "jaane",
    "jaana", "jaun", "jaaun", "ka", "ke", "ki", "mujhe", "mujhko", "navigate",
    "navigation", "karo", "kaise", "hai", "hain", "ko", "tak", "se", "liye", "kahan", "kaha",
}
NEWS_STOP = {
    "jarvis", "news", "khabar", "khabre", "khabrein", "batao", "sunao", "aaj", "ki", "ka",
    "ke", "latest", "today", "top", "mujhe", "liye", "headlines", "kya", "hai", "hain",
}


class Assistant:
    def __init__(self, settings, memory, gemini, live):
        self.settings = settings
        self.memory = memory
        self.gemini = gemini
        self.live = live
        self._pending = None  # (question, callable) - confirmation ke liye

    def handle(self, text):
        text = (text or "").strip()
        if not text:
            return "Kuch bolo ya likho, main sun rahi hoon."
        if self._pending is not None:
            reply = self._resolve_pending(text)
        else:
            reply = self._route(text)
            if reply is None:
                reply = self._ask_ai(text)
        self.memory.add_message("user", text)
        self.memory.add_message("assistant", reply)
        return reply

    # ---------- routing ----------
    def _route(self, text):
        handlers = (
            self._memory_cmd, self._tasks_cmd, self._alarm_or_timer, self._time_cmd,
            self._battery_cmd, self._torch_cmd, self._volume_cmd, self._settings_cmd,
            self._camera_cmd, self._music_cmd, self._open_app_cmd, self._call_cmd,
            self._sms_cmd, self._maps_cmd, self._weather_cmd, self._news_cmd,
            self._currency_cmd,
        )
        for handler in handlers:
            reply = handler(text)
            if reply is not None:
                return reply
        return None

    def _ask_ai(self, text):
        try:
            return self.gemini.ask(text, self.memory.recent())
        except GeminiError as e:
            return f"Abhi AI se jawab nahi mil paya. {e}"

    # ---------- confirmation ----------
    def _ask_confirm(self, question, action):
        self._pending = (question, action)
        return f"{question} (haan / nahi bolein)"

    def _resolve_pending(self, text):
        _, action = self._pending
        self._pending = None
        if has_word(text, *NO_WORDS) or not has_word(text, *YES_WORDS):
            return "Theek hai, cancel kar diya."
        try:
            return action()
        except ActionError as e:
            return f"Nahi ho paya: {e}"

    # ---------- handlers (None = match nahi hua) ----------
    def _memory_cmd(self, text):
        if not has_any(text, "yaad rakho", "yaad rakh lo"):
            return None
        if not self.memory.enabled:
            return "Memory band hai. '/memory on' karke dobara bolein."
        note = re.sub(r"yaad rakh(?:o| lo)", "", text, flags=re.IGNORECASE).strip(" :,.")
        if not note:
            return "Kya yaad rakhna hai? Jaise: 'yaad rakho mujhe coffee pasand hai'."
        self.memory.add_preference(note)
        return f"Theek hai, yaad rakh liya: {note}"

    def _tasks_cmd(self, text):
        if has_any(text, "task add", "task jodo"):
            item = re.split(r"task (?:add|jodo)", text, maxsplit=1, flags=re.IGNORECASE)[-1]
            item = item.strip(" :,.")
            if not item:
                return "Task ka text bataiye."
            self.memory.add_task(item)
            return f"Task jod diya: {item}"
        if has_any(text, "task done"):
            m = re.search(r"\d+", text)
            if not m:
                return "Kaunsa task complete hai? Number bataiye."
            if self.memory.complete_task(int(m.group())):
                return "Task complete mark kar diya."
            return "Ye task number list me nahi mila."
        if has_any(text, "tasks dikhao", "task list", "mere tasks", "tasks batao"):
            tasks = self.memory.tasks()
            if not tasks:
                return "Abhi koi task nahi hai."
            return "\n".join(f"{i}. {'✅' if t['done'] else '⬜'} {t['text']}"
                             for i, t in enumerate(tasks, 1))
        return None

    def _alarm_or_timer(self, text):
        low = text.lower()
        if has_word(text, "alarm"):
            m = re.search(r"(\d{1,2})(?::(\d{2}))?", low)
            if not m:
                return "Alarm ka time bataiye, jaise: 'kal subah 7 baje ka alarm'."
            hour, minute = int(m.group(1)), int(m.group(2) or 0)
            if has_word(text, "pm", "shaam", "sham", "raat") and hour < 12:
                hour += 12
            if has_word(text, "am", "subah") and hour == 12:
                hour = 0
            if not (0 <= hour <= 23 and 0 <= minute <= 59):
                return "Ye time sahi nahi lag raha."
            try:
                return act.set_alarm(hour, minute, "JARVIS alarm")
            except ActionError as e:
                return f"Alarm nahi lag paya: {e}"
        if has_word(text, "timer"):
            m = re.search(r"(\d+)\s*(second|sec|minute|min|ghante|ghanta|hour)", low)
            if not m:
                return "Timer kitna ka? Jaise: '5 minute ka timer'."
            seconds = int(m.group(1)) * TIME_UNITS[m.group(2)]
            try:
                return act.set_timer(seconds, "JARVIS timer")
            except ActionError as e:
                return f"Timer nahi lag paya: {e}"
        return None

    def _time_cmd(self, text):
        if not has_word(text, "time", "date", "samay", "tarikh") and not has_any(text, "kitne baje"):
            return None
        now = datetime.now()
        return f"Abhi {now:%d %B %Y}, {now:%I:%M %p} baj rahe hain."

    def _battery_cmd(self, text):
        if not has_word(text, "battery"):
            return None
        try:
            return act.battery()
        except ActionError as e:
            return str(e)

    def _torch_cmd(self, text):
        if not has_word(text, "torch", "flashlight") and not has_any(text, "टॉर्च"):
            return None
        turn_on = not has_word(text, "band", "off", "bujha", "bund")
        try:
            return act.torch(turn_on)
        except ActionError as e:
            return str(e)

    def _volume_cmd(self, text):
        if not has_word(text, "volume", "awaaz"):
            return None
        up = has_word(text, "badha", "badhao", "zyada", "tez", "up", "increase")
        down = has_word(text, "kam", "dhima", "low", "down", "decrease")
        if up == down:
            return "Volume badhana hai ya kam karna hai?"
        try:
            return act.change_volume(up)
        except ActionError as e:
            return str(e)

    def _settings_cmd(self, text):
        if not has_word(text, "settings", "kholo", "khol", "open"):
            return None
        for key, words in SETTINGS_KEYWORDS.items():
            if has_word(text, *words):
                try:
                    return act.open_settings(key)
                except ActionError as e:
                    return str(e)
        return None

    def _camera_cmd(self, text):
        if not has_word(text, "camera"):
            return None
        try:
            return act.open_camera()
        except ActionError as e:
            return str(e)

    def _music_cmd(self, text):
        if not is_music_command(text):
            return None
        query = parse_music_query(text)
        if not query:
            return "Kaunsa gaana chalana hai? Naam ya artist batayein."
        try:
            return act.open_youtube(query)
        except ActionError as e:
            return str(e)

    def _open_app_cmd(self, text):
        if not has_word(text, "kholo", "khol", "open"):
            return None
        for name in APP_PACKAGES:
            if has_word(text, name):
                try:
                    return act.open_youtube() if name == "youtube" else act.open_app(name)
                except ActionError as e:
                    return str(e)
        return None

    def _call_cmd(self, text):
        if not has_word(text, "call", "dial") and not has_any(text, "phone karo"):
            return None
        m = NUMBER_RE.search(text)
        if not m:
            return "Number bataiye, jaise: 'call 98765 43210 karo'."
        number = re.sub(r"[\s-]", "", m.group())

        def do_dial():
            act.dial(number)
            return "Dialer khul gaya, number bhar diya hai. Call button aap dabayein."

        return self._ask_confirm(f"{number} par dialer khol doon?", do_dial)

    def _sms_cmd(self, text):
        if not has_any(text, "message bhejo", "message karo", "sms bhejo", "message likho", "sms likho"):
            return None
        head, _, body = text.partition(":")
        m = NUMBER_RE.search(head)
        if not m:
            return "Number bataiye, jaise: 'message 98765 43210: kal milte hain'."
        if not body.strip():
            return "Message ka text ':' ke baad likhiye."
        number = re.sub(r"[\s-]", "", m.group())
        try:
            act.draft_sms(number, body.strip())
        except ActionError as e:
            return f"Messages app nahi khul paya: {e}"
        return "Messages app me draft khol diya hai. Send aap dabayein."

    def _maps_cmd(self, text):
        if not has_any(text, "rasta", "route", "direction", "navigate", "jaana hai", "kaise jaun"):
            return None
        dest = " ".join(w for w in normalize(text).split() if w not in MAPS_STOP)
        if not dest:
            return "Kahan ka rasta chahiye? Jaise: 'Connaught Place ka rasta dikhao'."
        try:
            return act.directions(dest)
        except ActionError as e:
            return str(e)

    def _weather_cmd(self, text):
        if not has_any(text, "mausam", "मौसम", "weather", "barish", "baarish", "temperature"):
            return None
        m = re.search(r"\b(?:in|mein|me)\s+([a-zA-Z]+)", text, flags=re.IGNORECASE)
        city = m.group(1) if m else self.settings.get("default_city")
        try:
            return self.live.weather(city)
        except LiveInfoError as e:
            return str(e)

    def _news_cmd(self, text):
        if not has_word(text, "news", "khabar", "khabre", "khabrein"):
            return None
        topic = " ".join(w for w in normalize(text).split() if w not in NEWS_STOP)
        try:
            return self.live.news(topic, self.settings.get("news_language"),
                                  self.settings.get("news_region"))
        except LiveInfoError as e:
            return str(e)

    def _currency_cmd(self, text):
        m = CURRENCY_RE.search(text)
        if not m:
            if has_any(text, "convert", "currency"):
                return "Aise likhiye: '100 USD to INR'."
            return None
        amount, src, dst = float(m.group(1)), m.group(2), m.group(3)
        try:
            return self.live.convert(amount, src, dst)
        except LiveInfoError as e:
            return str(e)
